#ifndef __TYPES_H
#define __TYPES_H

typedef int bool;
typedef unsigned char byte;
typedef unsigned int uint;
typedef unsigned long ulong;

#define false (0)
#define true (!false)

#endif
