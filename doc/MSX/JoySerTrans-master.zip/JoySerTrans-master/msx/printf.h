#ifndef __PRINTF_H
#define __PRINTF_H

int printf(const char *fmt, ...);

#endif